# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Teste2::Application.config.secret_token = '95aa5382e7352c416e4a9fe3eaeff94d1854ab01cd6b950b992c52fc7f8f5553e4508dbc8c2d2078373a876014da499dbc0cde3aaf3b8bd4a92fbd8dd4a31c2f'
