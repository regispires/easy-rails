require 'test_helper'

class ContatosHelperTest < ActionView::TestCase
end
