# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Teste1::Application.config.secret_token = '691b0768655721d0eb5c39acaed45e8568057c7d1d049cd8f4464458da189dc5a0fa91fcff5e18f0d594185ec8e8d9ad7c5883815911b3b2e67f7fe8e9c238e2'
