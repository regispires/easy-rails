# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Teste3::Application.config.secret_token = '2154003ed52513bc7ff5f3be68db7b20b0e4db2267eb8a45cdfdac490cece8ab59ca02ac043650d6aa1acc09bb6caf9bf5df529294eedea189f9e9267e049005'
